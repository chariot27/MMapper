﻿using MMapper.ConsoleApp.Entities;
using MMapper.ConsoleApp.ViewModels;
using MMapper.Lib;
using System;
using System.Text;

namespace MMapper.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var produtoViewModel = new ProdutoViewModel
            {
                Id = 1,
                Nome = "Produto A",
                Descricao = "Descrição do Produto A",
                Preco = 10.5m,
                PrecoForncedor = 7.5m,
                Estoque = 100,
                documentoCompra = "documento_em_string"
            };

            var configuration = new MapperConfiguration();
            var mapper = new MMapper(configuration);

            var produto = mapper.Map<ProdutoViewModel, Produto>(produtoViewModel);

            Console.WriteLine(produto.Nome);
            Console.WriteLine(produto.Preco);
            Console.WriteLine(produto.Descricao);
            Console.WriteLine(produto.documentoCompra.Length);
            var stringDocumentoCompra = Encoding.UTF8.GetString(produto.documentoCompra);
            Console.WriteLine(stringDocumentoCompra);
        }
    }
}
