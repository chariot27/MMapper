using System;

public class Evento { public DateTime DataEvento { get; set; } }